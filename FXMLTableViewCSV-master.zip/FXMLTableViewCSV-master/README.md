You don't need MS exel for your groupmates anymore, kappa.
